
import bankaccount.BankAccount;



public class BankDemo {

    public static void main(String[] args) {
        // Create a bank account with an initial balance
        BankAccount account = new BankAccount("Bob the Builder", 1500.00);

        // Display initial balance
        account.displayBalance();

        // Deposit funds
        account.deposit(200.00); // Expected new balance: 1700

        // Withdraw funds
        account.withdraw(450.00); // Expected new balance: 1250

        // Final balance
        account.displayBalance(); 
    }
}
