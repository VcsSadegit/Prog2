package bankaccount;

public class BankAccount {

    private String accountHolder;
    private double balance;

    // Constructor
    public BankAccount(String accountHolder, double balance) {
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    // Deposit method
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Depositing R" + amount);
            System.out.println("New balance: R" + balance);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    // Withdraw method
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawing R" + amount);
            System.out.println("New balance: R" + balance);
        } else {
            System.out.println("Insufficient funds or invalid amount.");
        }
    }

    // Display balance method
    public void displayBalance() {
        System.out.println("Account holder: " + accountHolder);
        System.out.println("Current balance: R" + balance);
    }
}
